﻿namespace Negocio.Valoraciones.ConPolimorfismo
{   
    public class ValorDeMercado
    {
        decimal elMontoConvertido;
        decimal elPrecioLimpio;

        public ValorDeMercado(DatosDeLaValoracionEnColones losDatos)
        {
            elMontoConvertido = losDatos.MontoConvertido;
            elPrecioLimpio = losDatos.PrecioLimpio;
        }

        public decimal ComoNumero()
        {
            return elMontoConvertido * (elPrecioLimpio / 100);
        }
    }
}