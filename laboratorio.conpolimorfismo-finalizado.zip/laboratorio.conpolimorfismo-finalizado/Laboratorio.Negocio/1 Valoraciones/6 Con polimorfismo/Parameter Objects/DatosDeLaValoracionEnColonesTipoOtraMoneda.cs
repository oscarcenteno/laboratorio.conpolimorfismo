﻿namespace Negocio.Valoraciones.ConPolimorfismo
{
    public class DatosDeLaValoracionEnColonesTipoOtraMoneda : DatosDeLaValoracionEnColones
    {
        public override decimal MontoConvertido
        {
            get
            {
                return MontoNominal;
            }
        }
    }
}