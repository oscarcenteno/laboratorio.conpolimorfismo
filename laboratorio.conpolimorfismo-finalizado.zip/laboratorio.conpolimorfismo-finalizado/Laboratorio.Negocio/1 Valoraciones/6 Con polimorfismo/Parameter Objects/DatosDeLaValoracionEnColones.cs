﻿namespace Negocio.Valoraciones.ConPolimorfismo
{
    public abstract class DatosDeLaValoracionEnColones
    {
        public decimal MontoNominal { get; set; }
        public decimal TipoDeCambio { get; set; }
        public decimal PrecioLimpio { get; set; }
        public decimal PorcentajeDeCobertura { get; set; }
        public abstract decimal MontoConvertido { get; }
    }
}