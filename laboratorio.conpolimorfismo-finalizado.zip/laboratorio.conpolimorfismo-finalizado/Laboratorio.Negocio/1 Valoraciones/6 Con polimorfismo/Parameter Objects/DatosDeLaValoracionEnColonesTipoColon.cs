﻿namespace Negocio.Valoraciones.ConPolimorfismo
{
    public class DatosDeLaValoracionEnColonesTipoColon : DatosDeLaValoracionEnColones
    {
        public override decimal MontoConvertido
        {
            get
            {
                return MontoNominal * TipoDeCambio;
            }
        }
    }
}
