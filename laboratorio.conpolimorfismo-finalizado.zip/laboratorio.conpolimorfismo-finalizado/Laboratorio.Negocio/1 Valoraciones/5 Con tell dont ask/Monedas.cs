﻿namespace Negocio.Valoraciones.ConTellDontAsk
{
    public enum Monedas
    {
        Colon,
        USDolar,
        UDEs
    }
}
