﻿using System;

namespace Negocio.RendimientosPorDescuento.ConPolimorfismo
{
    public class RendimientoPorDescuentoRedondeado
    {
        decimal elRendimiento;

        public RendimientoPorDescuentoRedondeado(DatosDeLaTasaBruta losDatos)
        {
            elRendimiento = new Rendimiento(losDatos).ComoNumero();
        }

        public decimal ComoNumero()
        {
            return Math.Round(elRendimiento, 4);
        }
    }
}