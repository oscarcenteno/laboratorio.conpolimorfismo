﻿namespace Negocio.RendimientosPorDescuento.ConPolimorfismo
{
    public abstract class DatosDeLaTasaBruta : DatosDelRendimientoPorDescuento
    {
        public decimal DiasAlVencimiento
        {
            get
            {
                return new DiasAlVencimiento(this).ComoNumero();
            }
        }

        public decimal TasaNeta => (ValorFacial - ValorTransadoNeto) / (ValorTransadoNeto * (DiasAlVencimiento / 365)) * 100;

        public abstract decimal ValorTransadoBruto { get; }
    }
}