﻿namespace Negocio.RendimientosPorDescuento.ConPolimorfismo
{
    public class DatosDeLaTasaBrutaConTratamientoFiscal : DatosDeLaTasaBruta
    {
        public override decimal ValorTransadoBruto
        {
            get
            {
                return new ValorTransadoBruto(this).ComoNumero();
            }
        }
    }
}