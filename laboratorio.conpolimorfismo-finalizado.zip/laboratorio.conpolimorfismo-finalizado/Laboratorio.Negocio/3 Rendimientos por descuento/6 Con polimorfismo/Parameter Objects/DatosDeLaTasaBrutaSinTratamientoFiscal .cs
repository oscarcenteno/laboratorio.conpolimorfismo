﻿namespace Negocio.RendimientosPorDescuento.ConPolimorfismo
{
    public class DatosDeLaTasaBrutaSinTratamientoFiscal : DatosDeLaTasaBruta
    {
        public override decimal ValorTransadoBruto
        {
            get
            {
                return ValorTransadoNeto;
            }
        }
    }
}