﻿namespace Negocio.RendimientosPorDescuento.ConPolimorfismo
{
    public class ValorTransadoBruto
    {
        decimal elValorFacial;
        decimal laTasaBruta;
        decimal losDiasAlVencimiento;

        public ValorTransadoBruto(DatosDeLaTasaBruta losDatos)
        {
            elValorFacial = losDatos.ValorFacial;
            losDiasAlVencimiento = losDatos.DiasAlVencimiento;
            laTasaBruta = new TasaBruta(losDatos).ComoNumero();
        }

        public decimal ComoNumero()
        {
            return elValorFacial / (1 + ((laTasaBruta / 100) * (losDiasAlVencimiento / 365)));
        }
    }
}