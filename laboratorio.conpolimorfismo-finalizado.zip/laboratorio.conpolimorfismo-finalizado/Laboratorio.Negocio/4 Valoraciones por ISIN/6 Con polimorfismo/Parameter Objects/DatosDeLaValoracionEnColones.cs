﻿namespace Negocio.ValoracionesPorISIN.ConPolimorfismo
{
    public class DatosDeLaValoracionEnOtraMoneda : DatosDeLaValoracion
    {
        public override decimal MontoConvertido
        {
            get
            {
                return MontoNominalDelSaldo;
            }
        }
    }
}