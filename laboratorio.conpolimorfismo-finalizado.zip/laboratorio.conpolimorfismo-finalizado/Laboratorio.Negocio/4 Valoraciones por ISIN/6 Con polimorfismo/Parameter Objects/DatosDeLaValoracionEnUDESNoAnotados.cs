﻿namespace Negocio.ValoracionesPorISIN.ConPolimorfismo
{
    public class DatosDeLaValoracionEnUDESNoAnotados : DatosDeLaValoracion
    {
        public override decimal MontoConvertido
        {
            get
            {
                return MontoNominalDelSaldo;
            }
        }
    }
}