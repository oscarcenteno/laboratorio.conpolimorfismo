﻿namespace Negocio.ValoracionesPorISIN.ConPolimorfismo
{
    public class DatosDeLaValoracionEnUDESAnotados : DatosDeLaValoracion
    {
        public override decimal MontoConvertido
        {
            get
            {
                // Los saldos en UDES se colonizan según el tipo de cambio de hoy, si no, el de ayer.
                if (TipoDeCambioDeUDESDeHoy > 0)
                    return MontoNominalDelSaldo * TipoDeCambioDeUDESDeHoy;
                else
                    return MontoNominalDelSaldo * TipoDeCambioDeUDESDeAyer;
            }
        }
    }
}