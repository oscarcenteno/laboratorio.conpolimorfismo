﻿using System;

namespace Negocio.ValoracionesPorISIN.ConPolimorfismo
{
    public abstract class DatosDeLaValoracion
    {
        public string ISIN { get; set; }
        public DateTime FechaActual { get; set; }
        public DateTime FechaDeVencimientoDelValorOficial { get; set; }
        public int DiasMinimosAlVencimientoDelEmisor { get; set; }
        public decimal PorcentajeCobertura { get; set; }
        public decimal PrecioLimpioDelVectorDePrecios { get; set; }
        public decimal MontoNominalDelSaldo { get; set; }
        public decimal TipoDeCambioDeUDESDeHoy { get; set; }
        public decimal TipoDeCambioDeUDESDeAyer { get; set; }

        public TimeSpan DiferenciaEntreLasFechas => FechaDeVencimientoDelValorOficial.Subtract(FechaActual);
        public abstract decimal MontoConvertido { get; }
    }
}