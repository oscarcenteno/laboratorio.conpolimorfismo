﻿namespace Negocio.ValoracionesPorISIN.ConObjetos
{
    public enum Monedas
    {
        UDES,
        Colon,
        Dolar
    }
}
