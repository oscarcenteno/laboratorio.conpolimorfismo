# Laboratorio.ConPolimorfismo
Este laboratorio nos permite practicar la herencia según el principio de sustitución de Liskov y el polimorfismo para lograr un diseño robusto.