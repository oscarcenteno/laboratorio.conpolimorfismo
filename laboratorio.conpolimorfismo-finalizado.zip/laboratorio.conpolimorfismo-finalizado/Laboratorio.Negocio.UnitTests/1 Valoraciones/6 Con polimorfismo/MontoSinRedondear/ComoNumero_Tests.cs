﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Negocio.Valoraciones.ConPolimorfismo;

namespace Laboratorio.Negocio.UnitTests.Valoraciones.ConPolimorfismo.MontoSinRedondear_Tests
{
    [TestClass]
    public class ComoNumero_Tests
    {
        private decimal elResultadoEsperado;
        private decimal elResultadoObtenido;
        private DatosDeLaValoracionEnColones losDatos;

        [TestMethod]
        public void ComoNumero_CasoUnico_LaFormula()
        {
            elResultadoEsperado = 6868534.95099M;

            InicialiceLosDatos();
            elResultadoObtenido = new MontoSinRedondear(losDatos).ComoNumero();

            Assert.AreEqual(elResultadoEsperado, elResultadoObtenido);
        }

        private void InicialiceLosDatos()
        {
            losDatos = new DatosDeLaValoracionEnColonesTipoColon();
            losDatos.MontoNominal = 10000;
            losDatos.TipoDeCambio = 758.19M;
            losDatos.PrecioLimpio = 100.6569M;
            losDatos.PorcentajeDeCobertura = 0.9M;
        }
    }
}
