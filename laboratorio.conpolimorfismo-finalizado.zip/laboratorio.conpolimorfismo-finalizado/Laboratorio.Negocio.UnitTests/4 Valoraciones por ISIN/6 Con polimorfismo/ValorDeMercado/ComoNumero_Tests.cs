﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Negocio.ValoracionesPorISIN.ConPolimorfismo;

namespace Negocio.UnitTests.ValoracionesPorISIN.ConPolimorfismo.ValorDeMercado__Tests
{
    [TestClass]
    public class ComoNumero_Tests
    {
        decimal elResultadoEsperado;
        decimal elResultadoObtenido;
        private DatosDeLaValoracion losDatos;

        [TestMethod]
        public void ComoNumero_UDESAnotadoEnCuentaYHayTipoDeCambioParaHoy_LaFormula()
        {
            elResultadoEsperado = 600000;

            InicialiceUDESAnotadoEnCuentaYHayTipoDeCambioParaHoy();
            elResultadoObtenido = new ValorDeMercado(losDatos).ComoNumero();

            Assert.AreEqual(elResultadoEsperado, elResultadoObtenido);
        }

        private void InicialiceUDESAnotadoEnCuentaYHayTipoDeCambioParaHoy()
        {
            losDatos = new DatosDeLaValoracionEnUDESAnotados();
            losDatos.PrecioLimpioDelVectorDePrecios = 80;
            losDatos.TipoDeCambioDeUDESDeAyer = 745;
            losDatos.MontoNominalDelSaldo = 1000;
            losDatos.TipoDeCambioDeUDESDeHoy = 750;
        }

        [TestMethod]
        public void ComoNumero_UDESNoAnotadoEnCuenta_LaFormula()
        {
            elResultadoEsperado = 800;

            InicialiceDatosEnUDESNoAnotados();
            elResultadoObtenido = new ValorDeMercado(losDatos).ComoNumero();

            Assert.AreEqual(elResultadoEsperado, elResultadoObtenido);
        }

        private void InicialiceDatosEnUDESNoAnotados()
        {
            losDatos = new DatosDeLaValoracionEnUDESNoAnotados();
            losDatos.PrecioLimpioDelVectorDePrecios = 80;
            losDatos.TipoDeCambioDeUDESDeAyer = 745;
            losDatos.MontoNominalDelSaldo = 1000;
            losDatos.TipoDeCambioDeUDESDeHoy = 750;
        }

        [TestMethod]
        public void ComoNumero_UDESAnotadoEnCuentaYNoHayTipoDeCambioParaHoy_LaFormula()
        {
            elResultadoEsperado = 596000;

            InicialiceDatosEnUDESAnotadoYNoHayTipoDeCambioParaHoy();
            elResultadoObtenido = new ValorDeMercado(losDatos).ComoNumero();

            Assert.AreEqual(elResultadoEsperado, elResultadoObtenido);
        }

        private void InicialiceDatosEnUDESAnotadoYNoHayTipoDeCambioParaHoy()
        {
            losDatos = new DatosDeLaValoracionEnUDESAnotados();
            losDatos.PrecioLimpioDelVectorDePrecios = 80;
            losDatos.TipoDeCambioDeUDESDeAyer = 745;
            losDatos.MontoNominalDelSaldo = 1000;
            losDatos.TipoDeCambioDeUDESDeHoy = 0;
            losDatos.TipoDeCambioDeUDESDeAyer = 745;
        }

        [TestMethod]
        public void ComoNumero_Colon_ElMontoNominalDelSaldo()
        {
            elResultadoEsperado = 2862400.0M;

            InicialiceDatosEnColones();
            elResultadoObtenido = new ValorDeMercado(losDatos).ComoNumero();

            Assert.AreEqual(elResultadoEsperado, elResultadoObtenido);
        }

        private void InicialiceDatosEnColones()
        {
            losDatos = new DatosDeLaValoracionEnOtraMoneda();
            losDatos.PrecioLimpioDelVectorDePrecios = 80;
            losDatos.TipoDeCambioDeUDESDeAyer = 745;

            losDatos.MontoNominalDelSaldo = 3578000;
            losDatos.TipoDeCambioDeUDESDeHoy = 750;
        }
    }
}